# BIO-Solutions
Solutions for the British Informatics Olympiad Problems

[BIO Website](https://www.olympiad.org.uk/)

All Solutions are currently only available in Python 3.

Solutions work for Part A of each question, with some solutions offering explained solutions for other parts of the question.

**Interested in personalised tutoring for the BIO or IOI? Don't hesitate to get in contact.**

Some solutions do not work fast enough, though in some cases this is due to the limitations of the Python 3 language.

If you have solution in any language feel free to send it in. All major languages welcome (within reason) and authors will be credited.

Currently missing perfect solutions include:

  - Egyptian Fractions 1997

With Thanks To:

  - Isaac Eason (Waves 2003)
