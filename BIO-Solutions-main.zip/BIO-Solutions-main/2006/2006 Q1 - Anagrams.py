a = sorted(list(input()))
b = sorted(list(input()))

if a == b:
    print("Anagrams")
else:
    print("Not anagrams")

"""
b) 6
c) 21
AAAAA
AAAAB
AAAAC
AAABB
AAACC
AAABC
AABBB
AACCC
AABCC
AABBC
ABBBB
ACCCC
ABBBC
ABBCC
ABCCC
BBBBB
CCCCC
BBBBC
BBBCC
BBCCC
BCCCC
"""